package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LlmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LlmsApplication.class, args);
	}

}
